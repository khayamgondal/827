def fff():
  if 1<5:
    print 235
  y = 4
  if y < 3:
    print 99
  else:
    x = 4
    x = x+ 15
    x = x-99
    print x
  print 8065
  def q():
    print 33
    print 1111
    def lm():
      print 65
    lm();
  q()
print 1991
fff()
