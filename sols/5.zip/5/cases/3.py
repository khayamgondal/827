def f():
  if 1==1:
    print 2
  if 2<=2:
    print 13
  return
  print 5
  return

def k():
  x=5
  if x==1:
    print x
    x = x+5
  if x==5:
    print 2
    x = x+9
    print x
    return
  if 2==2:
    print 3
  return
  print 5
  return

k()
k()
f()
