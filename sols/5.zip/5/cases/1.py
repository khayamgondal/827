def f():
  if 1==1:
    print 2
  if 2==1:
    print 2
  if 2==2:
    print 3
  return
  print 5
  return
f()

